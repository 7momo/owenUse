function createCORSRequest(method, url){
    var xhr = new XMLHttpRequest();
    if ("withCredentials" in xhr){
        xhr.open(method, url, true);
    } else if (typeof XDomainRequest != "undefined"){
        xhr = new XDomainRequest();
        xhr.open(method, url);
    } else {
        xhr = null;
    }
    return xhr;
}

var request = createCORSRequest("get", "http://10.50.200.102:81/");
if (request){
    request.onreadystatechange = function(){
        if (request.readyState == 4 && request.status == 200) {
	            var response = request.responseText;
	            console.log(response);
        	}  
        }
    request.send();
}