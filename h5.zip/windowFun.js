function CloseWebPage(){
 if (navigator.userAgent.indexOf("MSIE") > 0) {
  if (navigator.userAgent.indexOf("MSIE 6.0") > 0) {
   window.opener = null;
   window.close();
  } else {
   window.open('', '_top');
   window.top.close();
  }
 }
 else if (navigator.userAgent.indexOf("Firefox") > 0) {
  window.location.href = 'about:blank ';
 } else {
	if(window.history.length<=1){
		window.opener = null;
		window.open('', '_self', '');
		window.close();
	}else{
		window.history.go(-1);
	}
 }
}

var ua = navigator.userAgent,
  chrome = ua.match(/Chrome\/([\d.]+)/) || ua.match(/CriOS\/([\d.]+)/),
  webview = !chrome && ua.match(/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/);

function CloseIOSPage(){
	if(!webview || typeof(webview) === 'undefined' || webview === null){
		CloseWebPage();
	}else
	{
		window.location.href = "iOS:exitWebViewController";
	}
}
function CloseAndriodPage(){
	if (typeof(androidJs) === 'object' && typeof(androidJs.finishGame) === 'function') {
		androidJs.finishGame();
	}else
	{
		CloseWebPage();
	}
}

function checkWindowShow(){
	document.addEventListener(visibilityChange, function() {
	values = 0;
	if( document[state] == "hidden" ){
		startTime = new Date().getTime();
	}else if( document[state] == "visible" ){
		endTime = new Date().getTime();
	}
	
	values  = endTime - startTime;
	
	console.log( "窗口变化==state="+ document[state]+",startTime="+startTime+",endTime="+endTime+",values="+values);
	
	if( values >= 7 * 1000 ){
		console.log( "刷新页面refresh");
		//window.navigate(location); 
		location.reload();
	}
	}, false);
}


function SetCookie(name,value)
{
	var Days = 30; //此 cookie 将被保存 30 天
	var exp = new Date();
	exp.setTime(exp.getTime() + Days*24*60*60*1000);
	document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
	var a = 0;
}

///删除cookie
function delCookie(name)
{
	var exp = new Date();
	exp.setTime(exp.getTime() - 1);
	var cval=getCookie(name);
	if(cval!=null) document.cookie= name + "="+cval+";expires="+exp.toGMTString();
}

//读取cookie
function getCookie(name)
{
 	var arr = document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
	if(arr != null)
	return unescape(arr[2]);
	return null;
}


function openNewWindow(urlss)
{
	
}

var btn;
var startTime, endTime,values;

// 各种浏览器兼容
var hidden, state, visibilityChange; 
if (typeof document.hidden !== "undefined") {
hidden = "hidden";
visibilityChange = "visibilitychange";
state = "visibilityState";
} else if (typeof document.mozHidden !== "undefined") {
hidden = "mozHidden";
visibilityChange = "mozvisibilitychange";
state = "mozVisibilityState";
} else if (typeof document.msHidden !== "undefined") {
hidden = "msHidden";
visibilityChange = "msvisibilitychange";
state = "msVisibilityState";
} else if (typeof document.webkitHidden !== "undefined") {
hidden = "webkitHidden";
visibilityChange = "webkitvisibilitychange";
state = "webkitVisibilityState";
}